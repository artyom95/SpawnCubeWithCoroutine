using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecoloringBehaviour : MonoBehaviour
{
 

  [SerializeField] 
  private float _intervalRecoloring;
  [SerializeField] 
  private float _durationRecoloring;

  private PrefabsInstantiate _prefabsInstantiate;
  private GameObject[,] _array = new GameObject[20, 20];

  private void FillArray()
  {
    _array = _prefabsInstantiate.GetArray();
  }
  private Color GetCurrentColor()
  {
    var material = gameObject.GetComponent<Renderer>().material;
    var color = material.color;
    return color;
  }
  private Color GetNextColor()
  {
     var color = Random.ColorHSV(0.8f,1f,0.5f,1f,1f,1f);
    return color;
  }

  public void Recolor()
  {
    FillArray();
    StartCoroutine(GetObjectInArray());
  }
  private IEnumerator GetObjectInArray()
  {
   
    for (int i = 0; i < _array.GetLength(0); i++)
    {
     for (int j = 0; j < _array.GetLength(1); j++)
     {
       StartCoroutine(ChangeColor(_array[i,j]));
       yield return new WaitForSeconds(_intervalRecoloring);
     }
    }
  }
  private IEnumerator ChangeColor(GameObject gameObject)
  {
    var time = 0f;
    var currentColor = GetCurrentColor();
    var nextColor = GetNextColor();
    while (time < _durationRecoloring)
    {
      gameObject.GetComponent<Renderer>().material.color =
        Color.Lerp(currentColor, nextColor, time / _durationRecoloring);
      time += Time.deltaTime;
      yield return null;
    }
  }
}
